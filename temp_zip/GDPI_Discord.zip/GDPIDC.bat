@echo off
tasklist | find "goodbyedpi" && echo yes || (echo no & start "DiscordAPP" /D "%~dp0" "%~dp0goodbyedpi.exe" --set-ttl 7 --blacklist "%~dp0discord4.txt")
"C:\Users\sirius\AppData\Local\discord\Update.exe" --processStart Discord.exe
exit